// AfriLaunch AI — Tests E2E (Playwright)
import { test, expect, Page } from '@playwright/test';

const BASE_URL = process.env.BASE_URL ?? 'http://localhost:3000';

// ── Auth Tests ────────────────────────────────────────────────
test.describe('Authentication', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(BASE_URL);
  });

  test('Landing page loads correctly', async ({ page }) => {
    await expect(page.getByText('AfriLaunch AI')).toBeVisible();
    await expect(page.getByText('Commencer gratuitement')).toBeVisible();
    await expect(page.getByText('empire digital')).toBeVisible();
  });

  test('Registration flow works', async ({ page }) => {
    await page.goto(`${BASE_URL}/register`);

    await page.fill('[name="firstName"]', 'Kwame');
    await page.fill('[name="lastName"]', 'Mensah');
    await page.fill('[name="email"]', `test+${Date.now()}@afrilaunch.test`);
    await page.fill('[name="password"]', 'AfriLaunch2025!');
    await page.fill('[name="confirmPassword"]', 'AfriLaunch2025!');
    await page.selectOption('[name="country"]', 'GH');

    await page.click('[type="submit"]');
    await page.waitForURL(`${BASE_URL}/dashboard/**`, { timeout: 10000 });

    await expect(page.getByText('Tableau de bord')).toBeVisible();
  });

  test('Login with valid credentials', async ({ page }) => {
    await page.goto(`${BASE_URL}/login`);

    await page.fill('[name="email"]', process.env.TEST_USER_EMAIL!);
    await page.fill('[name="password"]', process.env.TEST_USER_PASSWORD!);
    await page.click('[type="submit"]');

    await page.waitForURL(`${BASE_URL}/dashboard/**`);
    await expect(page.getByText('Tableau de bord')).toBeVisible();
  });

  test('Login with invalid credentials shows error', async ({ page }) => {
    await page.goto(`${BASE_URL}/login`);

    await page.fill('[name="email"]', 'wrong@test.com');
    await page.fill('[name="password"]', 'wrongpassword');
    await page.click('[type="submit"]');

    await expect(page.getByText(/identifiants invalides|invalid credentials/i)).toBeVisible();
  });

  test('Google OAuth button is visible', async ({ page }) => {
    await page.goto(`${BASE_URL}/login`);
    await expect(page.getByText(/Continuer avec Google/i)).toBeVisible();
  });
});

// ── Dashboard Tests ───────────────────────────────────────────
test.describe('Dashboard', () => {
  test.beforeEach(async ({ page }) => {
    // Login
    await page.goto(`${BASE_URL}/login`);
    await page.fill('[name="email"]', process.env.TEST_USER_EMAIL!);
    await page.fill('[name="password"]', process.env.TEST_USER_PASSWORD!);
    await page.click('[type="submit"]');
    await page.waitForURL(`${BASE_URL}/dashboard/**`);
  });

  test('Dashboard displays all key sections', async ({ page }) => {
    await expect(page.getByText('Votre parcours')).toBeVisible();
    await expect(page.getByText('Recommandations IA')).toBeVisible();
    await expect(page.getByText('Actions rapides')).toBeVisible();
    await expect(page.getByText('Réseaux sociaux')).toBeVisible();
    await expect(page.getByText('Activités récentes')).toBeVisible();
  });

  test('Stats grid shows metrics', async ({ page }) => {
    await expect(page.getByText('Portée totale')).toBeVisible();
    await expect(page.getByText('Abonnés cumulés')).toBeVisible();
    await expect(page.getByText('Interactions')).toBeVisible();
  });

  test('Quick actions navigate correctly', async ({ page }) => {
    await page.click('button:has-text("Créer mon identité")');
    await page.waitForURL(`${BASE_URL}/dashboard/identity`);
    await expect(page.getByText(/identité|branding/i)).toBeVisible();
  });
});

// ── Brand Identity Tests ──────────────────────────────────────
test.describe('Brand Identity Module', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(`${BASE_URL}/login`);
    await page.fill('[name="email"]', process.env.TEST_USER_EMAIL!);
    await page.fill('[name="password"]', process.env.TEST_USER_PASSWORD!);
    await page.click('[type="submit"]');
    await page.waitForURL(`${BASE_URL}/dashboard/**`);
    await page.goto(`${BASE_URL}/dashboard/identity`);
  });

  test('Brand creation form is visible', async ({ page }) => {
    await expect(page.getByText(/Créer votre identité|Brand Identity/i)).toBeVisible();
    await expect(page.getByPlaceholder(/secteur|industry/i)).toBeVisible();
  });

  test('Can generate brand identity', async ({ page }) => {
    await page.fill('[placeholder*="secteur"]', 'Restaurant');
    await page.fill('[placeholder*="description"]', 'Restaurant africain traditionnel');
    await page.click('button:has-text("Générer")');

    // Wait for AI response
    await page.waitForSelector('[data-testid="brand-name"]', { timeout: 30000 });
    const brandName = await page.getByTestId('brand-name').textContent();
    expect(brandName).toBeTruthy();
    expect(brandName!.length).toBeGreaterThan(2);
  });
});

// ── AI Agent Tests ────────────────────────────────────────────
test.describe('AI Agents Marketplace', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(`${BASE_URL}/login`);
    await page.fill('[name="email"]', process.env.TEST_USER_EMAIL!);
    await page.fill('[name="password"]', process.env.TEST_USER_PASSWORD!);
    await page.click('[type="submit"]');
    await page.waitForURL(`${BASE_URL}/dashboard/**`);
    await page.goto(`${BASE_URL}/dashboard/agents`);
  });

  test('All 13 agents are displayed', async ({ page }) => {
    const agents = ['Branding', 'Marketing', 'Publicité', 'SEO', 'YouTube',
                    'TikTok', 'Facebook', 'Instagram', 'CRM', 'Support',
                    'Analyse', 'Comptabilité', 'Business'];

    for (const agent of agents) {
      await expect(page.getByText(`Agent ${agent}`)).toBeVisible();
    }
  });

  test('Can start a session with Branding agent', async ({ page }) => {
    await page.click('button:has-text("Agent Branding")');
    await page.waitForSelector('[data-testid="agent-chat"]');

    await page.fill('[placeholder*="message"]', 'J\'ai un restaurant africain à Abidjan');
    await page.click('[type="submit"]');

    await page.waitForSelector('[data-testid="agent-response"]', { timeout: 20000 });
    const response = await page.getByTestId('agent-response').first().textContent();
    expect(response).toBeTruthy();
  });
});

// ── Content Generation Tests ──────────────────────────────────
test.describe('Content Generation', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(`${BASE_URL}/login`);
    await page.fill('[name="email"]', process.env.TEST_USER_EMAIL!);
    await page.fill('[name="password"]', process.env.TEST_USER_PASSWORD!);
    await page.click('[type="submit"]');
    await page.waitForURL(`${BASE_URL}/dashboard/**`);
    await page.goto(`${BASE_URL}/dashboard/content`);
  });

  test('Content types are displayed', async ({ page }) => {
    const types = ['Facebook', 'Instagram', 'YouTube', 'TikTok', 'Email', 'Blog'];
    for (const type of types) {
      await expect(page.getByText(type)).toBeVisible();
    }
  });

  test('Can generate a Facebook post', async ({ page }) => {
    await page.click('button:has-text("Facebook")');
    await page.fill('[placeholder*="sujet"]', 'Lancement de mon nouveau produit');
    await page.click('button:has-text("Générer")');

    await page.waitForSelector('[data-testid="generated-content"]', { timeout: 30000 });
    const content = await page.getByTestId('generated-content').textContent();
    expect(content!.length).toBeGreaterThan(50);
  });
});

// ── Payment Tests ─────────────────────────────────────────────
test.describe('Payment Recommendations', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(`${BASE_URL}/login`);
    await page.fill('[name="email"]', process.env.TEST_USER_EMAIL!);
    await page.fill('[name="password"]', process.env.TEST_USER_PASSWORD!);
    await page.click('[type="submit"]');
    await page.waitForURL(`${BASE_URL}/dashboard/**`);
    await page.goto(`${BASE_URL}/dashboard/payments`);
  });

  test('Shows payment recommendations for user country', async ({ page }) => {
    await expect(page.getByText(/recommandé|recommended/i)).toBeVisible();
    await expect(page.getByText(/Flutterwave|Paystack|Orange Money|MTN/i)).toBeVisible();
  });
});

// ── Accessibility Tests ───────────────────────────────────────
test.describe('Accessibility', () => {
  test('Landing page has proper aria labels', async ({ page }) => {
    await page.goto(BASE_URL);
    const buttons = page.getByRole('button');
    const count = await buttons.count();
    expect(count).toBeGreaterThan(0);
  });

  test('Forms have proper labels', async ({ page }) => {
    await page.goto(`${BASE_URL}/register`);
    const emailInput = page.getByLabel(/email/i);
    await expect(emailInput).toBeVisible();
  });

  test('Page has proper heading structure', async ({ page }) => {
    await page.goto(BASE_URL);
    const h1 = page.getByRole('heading', { level: 1 });
    await expect(h1).toBeVisible();
  });
});

// ── Performance Tests ─────────────────────────────────────────
test.describe('Performance', () => {
  test('Landing page loads in under 3 seconds', async ({ page }) => {
    const start = Date.now();
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');
    const duration = Date.now() - start;
    expect(duration).toBeLessThan(3000);
  });

  test('Dashboard loads in under 5 seconds', async ({ page }) => {
    await page.goto(`${BASE_URL}/login`);
    await page.fill('[name="email"]', process.env.TEST_USER_EMAIL!);
    await page.fill('[name="password"]', process.env.TEST_USER_PASSWORD!);

    const start = Date.now();
    await page.click('[type="submit"]');
    await page.waitForURL(`${BASE_URL}/dashboard/**`);
    const duration = Date.now() - start;
    expect(duration).toBeLessThan(5000);
  });
});
